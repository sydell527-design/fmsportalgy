# FMS TimeTrack — Replit Deployment Guide

## What This Is
A full-stack React workforce management system built for **Federal Management Systems (FMS), Georgetown, Guyana**.

**Features:**
- Clock In / Clock Out with GPS geofencing (OpenStreetMap — no API key)
- Dual-signature timesheet approval workflow (position-based)
- Guyana 2026 payroll: NIS 5.6% employee / 8.4% employer, PAYE 28%
- Employee management with forced password change on first login
- Leave / Overtime request system
- Reports & analytics
- Geofencing zone manager (Leaflet + OpenStreetMap, free)
- Multi-role: Admin / Manager / Employee

---

## Quick Setup on Replit

### Option A — React App (Recommended)

1. Create a new **React** repl
2. Delete everything in `src/`
3. Rename `fms-timetrack.jsx` → `src/App.jsx`
4. Replace `src/index.js` with:
   ```js
   import React from 'react';
   import ReactDOM from 'react-dom/client';
   import App from './App';
   ReactDOM.createRoot(document.getElementById('root')).render(<App />);
   ```
5. Replace `public/index.html` `<body>` with:
   ```html
   <body>
     <div id="root"></div>
   </body>
   ```
6. In `src/App.jsx`, find the bottom `App` component export and make sure it ends with:
   ```jsx
   export default App;
   ```
7. Click **Run**

### Option B — Vite React (Faster)

```bash
npm create vite@latest fms-timetrack -- --template react
cd fms-timetrack
npm install
```
Copy `fms-timetrack.jsx` → `src/App.jsx`, then `npm run dev`.

---

## Storage Compatibility

The app currently uses `window.storage` (Claude.ai's built-in persistent storage API).

**For Replit, replace `window.storage` with `localStorage`:**

Find the `save` and `load` helper functions (around line 670) and replace them:

```js
// REPLIT VERSION — replace the existing save/load functions
const save = (key, val) => {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch(e) {}
};
const load = async (key) => {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : null;
  } catch(e) { return null; }
};
```

Also find any direct `window.storage.get` / `window.storage.set` calls (e.g. in GeofencingPanel for `fms:gmapsKey`) and replace with:
```js
// window.storage.get("fms:gmapsKey") → localStorage.getItem("fms:gmapsKey")
// window.storage.set("fms:gmapsKey", k) → localStorage.setItem("fms:gmapsKey", k)
```

---

## Login Credentials

| Role | Username | Password | Notes |
|------|----------|----------|-------|
| Admin | ADMIN001 | admin123 | Full access — Shemar Ferguson |
| Manager | MGR001 | manager123 | Sandra Ali — Operations Manager |
| Employee | 1001 | temp | Marcus Webb — must change password on first login |
| Employee | 1002 | temp | Priya Sharma |
| Employee | 1003 | temp | Devon Charles |
| Employee | 1004 | temp | Jordan Baptiste |
| Employee | 1005 | (set by admin) | Troy Mason |

---

## GPS / Geofencing

- Uses **navigator.geolocation** (browser native — no API key)
- Map tiles: **OpenStreetMap** via Leaflet (free, no account)
- Configured zones:
  - **HEAD OFFICE** → 6.813348, -58.147854 (radius 150m)
  - **CARICOM** → 6.820398, -58.116849 (radius 200m)
  - EU, UN, DMC, ARU, CANTEEN → no zone yet (add in Geofencing panel)

**Note:** On Replit the browser will show a real location permission popup. On Claude.ai it was blocked by the iframe sandbox — this is fixed on Replit.

---

## Payroll Configuration (Guyana 2026)

Located at the top of the file in the `TAX` constant:
```js
const TAX = {
  NIS_EMP: 0.056,       // 5.6% employee NIS
  NIS_EMPLR: 0.084,     // 8.4% employer NIS
  NIS_CEIL: 280000,     // NIS ceiling GYD
  PERSONAL_ALLOW: 100000, // Personal allowance/month GYD
  PAYE: 0.28,           // 28% income tax
  OT: 1.5,              // Overtime multiplier
  HOLIDAY: 2.0,
  WEEKEND: 1.5,
};
```

---

## Architecture Notes

- **Single JSX file** — entire app in one file, no backend needed
- **Position-based approvals** — `emp.fa` and `emp.sa` store position title strings, NOT employee IDs
- **Employee ID = Username** — no separate username field
- **emp.geo is always an array** — `["HEAD OFFICE", "CARICOM"]`
- **EmpForm defined OUTSIDE EmployeesPanel** — keeps input focus stable

---

## Session History (S01–S19)

Full development history is embedded at the top of `fms-timetrack.jsx` as a comment block (lines 1–230). Read it before making changes.

